#include <cmath>
#include <Rmath.h>
#include "RcppArmadillo.h"

#include <iostream>
#include <boost/math/special_functions/bessel.hpp>  // included in BH  

// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;
using namespace Rcpp;
using namespace std;
// [[Rcpp::depends(BH)]]    

// [[Rcpp::export]]   
double computeBESSEL(double k, double x) {
  return boost::math::cyl_bessel_k( k,x );
}

// [[Rcpp::export]]   
arma::mat computeMTRN(arma::mat distM, double range,double smoothness, double phi){
  int n = distM.n_rows;
  double Dist, con1, con;
  arma::mat Gdist1(n,n);
  
  for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
      Dist = distM(i,j)*(1/range);
      if(Dist<=0){
        Dist=1e-10;
      }
      con1 = (pow(2,(smoothness - 1))) * tgamma(smoothness);
      con = (1/con1);
      Gdist1(i,j) = (phi * con * pow(Dist,smoothness) * boost::math::cyl_bessel_k(smoothness,Dist));
    }  
  }
  return Gdist1;
}

// [[Rcpp::export]]
arma::mat mvrnormArma(arma::mat Z,arma::vec mu, arma::mat sigma) {
  int n = Z.n_rows;
  arma::mat R1 = sigma.t()*sigma;
  
  bool success = false;

  while(success == false)
  {
   success = chol(R1, sigma);

  if(success == false)
    {
     sigma = diagmat(sigma);
    }
  }
  
  return arma::repmat(mu, 1, n).t() + Z * arma::chol(sigma);
}


// [[Rcpp::export]]
arma::vec Log_likelihoodCpp(arma::mat xdata,arma::mat y,arma::mat distM,arma::vec para,arma::mat Z,double r01,double r02){
  int a = distM.n_rows, B=Z.n_rows, n=xdata.n_rows;
  arma::mat diag1(a,a),Gd1(a,a),C1(a,a),W11(B,a),W1(a,B),Gd2(a,a),C2(a,a),W22(B,a),W2(a,B);
  arma::vec mu(a), mu11(n),log_mu2(n),Loglk_Y1(n),log_like(n),Joint_pd(n),mu1(B), mu2(B), Lk_Y1(B),u11(B),u22(B),u22_low(B),partial_lk(B);
  double r11,r12,r21,r22,KP1,KP2,PHI1,PHI2,Cl_Cop1,Cl_up,Cl_Cop2,Cl_low,Cl_diff;
  double sd1=pow(exp(para[3]),0.5);
  double tau1=1/(1+exp(-para[13]));
  double alpha_Cl=((2*tau1)/(1-tau1));
  
  mu.zeros();
  diag1.eye();
  r11 = (exp(para[4]))*(exp(para[5]));
  r21 = exp(para[5]);
  r12 = (exp(para[10]))*(exp(para[11]));
  r22 = exp(para[11]);
  
  KP1= exp(para[6]);
  KP2= exp(para[12]);
  PHI1=(r11+r01);
  PHI2=(r12+r02);
  
  Gd1=computeMTRN(distM, r21,KP1, PHI1);  
  W11 = mvrnormArma(Z,mu, Gd1);
  W1 = W11.t();
  
  Gd2=computeMTRN(distM, r22,KP2, PHI2);
  
  W22 = mvrnormArma(Z,mu, Gd2);
  W2 = W22.t();
  
  for(int i = 0; i < n; i++) {
    mu11[i] = para[0]+(para[1]*xdata(i,0))+(para[2]*xdata(i,1));
    log_mu2[i] = para[7]+(para[8]*xdata(i,0))+(para[9]*xdata(i,1));
    
    for(int j = 0; j < B; j++) {
      mu1[j] = mu11[i]+W1(i,j);
      u11[j] = R::pnorm(y(i,0),mu1[j],sd1,1,0);
      Lk_Y1[j]=R::dnorm(y(i,0),mu1[j],sd1,1);
      mu2[j] = exp(log_mu2[i]+W2(i,j));
      u22[j]=R::ppois(y(i,1),mu2[j],1,0);
      u22_low[j]=R::ppois(y(i,1)-1,mu2[j],1,0);
      
      Cl_Cop1 = pow(pow(u11[j],-alpha_Cl)+pow(u22[j],-alpha_Cl)-1,(-1/alpha_Cl));
      if(Cl_Cop1 < 0)
        Cl_Cop1= 0;
      if(Cl_Cop1 > 1)
        Cl_Cop1= 1;
      
      Cl_up = Cl_Cop1*(pow(u11[j],(-alpha_Cl-1))/(pow(u11[j],-alpha_Cl)+pow(u22[j],-alpha_Cl)-1));
      if(Cl_up < 0)
        Cl_up= 0;
      if(Cl_up > 1)
        Cl_up= 1;
      
      Cl_Cop2 = pow(pow(u11[j],-alpha_Cl)+pow(u22_low[j],-alpha_Cl)-1,(-1/alpha_Cl));
      if(Cl_Cop2 < 0)
        Cl_Cop2= 0;
      if(Cl_Cop2 > 1)
        Cl_Cop2= 1;
      
      Cl_low = Cl_Cop2*(pow(u11[j],(-alpha_Cl-1))/(pow(u11[j],-alpha_Cl)+pow(u22_low[j],-alpha_Cl)-1));
      if(Cl_low < 0)
        Cl_low= 0;
      if(Cl_low > 1)
        Cl_low= 1;
      
      Cl_diff = (Cl_up-Cl_low);
      if(Cl_diff <= 0)
        Cl_diff= 1e-100; 
      partial_lk[j]=Cl_diff;
    }
    
    Joint_pd[i] = mean(partial_lk);
    Loglk_Y1[i] = mean(Lk_Y1);
    
    log_like[i] = Loglk_Y1[i]+log(Joint_pd[i]);
  }
  
  return log_like;
}

// [[Rcpp::export]]
arma::mat Res_Clcpp(arma::mat xdata,arma::mat distM,arma::vec para,arma::mat Z1,arma::mat Z2,arma::vec Z3,arma::vec v2,double r01,double r02){
  int a = distM.n_rows;
  arma::mat diag1(a,a),Gd1(a,a),W11(1,a),Gd2(a,a),W22(1,a),Y(a,2);
  arma::vec mu(a),mu1(a),mu2(a),log_mu2(a),W1(a),W2(a),u1(a),u2_cl(a);
  double r11,r12,r21,r22,KP1,KP2,PHI1,PHI2;
  double sd1=pow(exp(para[3]),0.5);
  double tau1=1/(1+exp(-para[13]));
  double alpha_Cl=((2*tau1)/(1-tau1));
  
  mu.zeros();
  diag1.eye();
  r11 = (exp(para[4]))*(exp(para[5]));
  r21 = exp(para[5]);
  r12 = (exp(para[10]))*(exp(para[11]));
  r22 = exp(para[11]);
  
  KP1= exp(para[6]);
  KP2= exp(para[12]);
  if(KP1>10 || KP1<0){
    KP1=10;
  }
  if(KP2>10 || KP2<0){
    KP2=10;
  }
  
  
  PHI1=(r11+r01);
  PHI2=(r12+r02);
  
  Gd1=computeMTRN(distM, r21,KP1, PHI1);  
  W11 = mvrnormArma(Z1,mu, Gd1);
  W1 = W11.t();
  
  Gd2=computeMTRN(distM, r22,KP2, PHI2);
  W22 = mvrnormArma(Z2,mu, Gd2);
  W2 = W22.t();
 
  
  for(int i = 0; i < a; i++) {
    mu1[i] = para[0]+(para[1]*xdata(i,0))+(para[2]*xdata(i,1))+W1[i];
    log_mu2[i] = para[7]+(para[8]*xdata(i,0))+(para[9]*xdata(i,1))+W2[i];
    mu2[i] =exp(log_mu2[i]);
    Y(i,0)= Z3[i]*sd1+mu1[i];
    u1[i]=R::pnorm(Y(i,0),mu1[i],sd1,1,0);
    u2_cl[i] = pow((pow(u1[i],-alpha_Cl)*(pow(v2[i],(-alpha_Cl/(1+alpha_Cl)))-1)+1),(-1/alpha_Cl));
    Y(i,1)= R::qpois(u2_cl[i],mu2[i],1,0);
  }    
  
  return Y; 
}

// [[Rcpp::export]]
arma::vec Pred_utecpp(arma::mat X_unsamp,arma::mat distM,arma::mat post1,arma::vec v2,double r01,double r02){ 
  int K = post1.n_rows, R = 100, n=X_unsamp.n_rows,a = post1.n_cols ;
  double pi=22/7;
  
  arma::mat SigY(2,2),Ym(n,2),dataY(R,2),Avg_Hz(K,n) ;
  arma::vec Pred_ute(K), z33_new(n),y1_sub(R),y2_sub(R),Sum_Hz(K),Hz(n),post_samp1(a) ;
  arma::mat Y1= arma::zeros(R,n),Y2= arma::zeros(R,n);
  
  for(int m = 0; m < K; m++) {
    post_samp1= vectorise(post1.row(m));
    for(int r = 0; r < R; r++) {
      mat z1_new(1,n,fill::randn);
      mat z2_new(1,n,fill::randn);
      mat z3_new(1,n,fill::randn);
      z33_new=vectorise(z3_new.row(0));
      Ym = Res_Clcpp(X_unsamp,distM,post_samp1,z1_new,z2_new,z33_new,v2,r01,r02);
      for(int p = 0; p < n; p++ ){
        Y1(r,p)=Ym(p,0);
        Y2(r,p)=Ym(p,1);
      }
    }
    for(int i = 0; i < n; i++){ 
      y1_sub = vectorise(Y1.col(i));
      y2_sub = vectorise(Y2.col(i));
      dataY.col(0) = y1_sub;
      dataY.col(1) = y2_sub;
      SigY = cov(dataY);
      if(det(SigY)<=0){
        Hz[i] = 0;
      }else{
        Hz[i] = (1+log(2*pi))+log(det(SigY))/2;
      }
      
      if(Hz[i]>1e100){
        Hz[i]=0;
      }
      if(Hz[i]<(-1e100)){
        Hz[i]=0;
      }
    }
    Sum_Hz[m] = sum(Hz);
  }  
  Pred_ute= -1*mean(Sum_Hz);
  return Pred_ute;
}

